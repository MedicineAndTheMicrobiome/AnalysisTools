#ifndef BMTAGGER_VERSION__hpp
#define BMTAGGER_VERSION__hpp

#include "../oalign/oligofar-version.hpp"
#define BMTAGGER_VERSION OLIGOFAR_VERSION

#endif
